export const environment = {
  production: true,
  ProductionUrl:  'http://52.175.23.235:3000/test/',
};

import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SignUpService } from './sign-up.service';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.scss']
})
export class SignUpComponent implements OnInit {
  public signUpForm: FormGroup;
  public emailPattern = '^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$';
  constructor(private router: Router, private signUpService: SignUpService) {

    this.signUpForm = new FormGroup({
      userName: new FormControl('', [
        Validators.required,
       ]),
      email: new FormControl('', [
        Validators.required,
        Validators.pattern(this.emailPattern)
       ]),
      dob: new FormControl('', [
        Validators.required,
       ]),
      phoneNumber: new FormControl('', [
        Validators.required
       ]),
      password: new FormControl('', [Validators.required,
        Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]),
      confirmPassword: new FormControl('', [
        Validators.required,
        Validators.pattern(this.passwordMatcher.bind(this))
       ]),
    });

  }

  private passwordMatcher(control: FormControl): { [s: string]: boolean } {
    if (
        this.signUpForm &&
        (control.value !== this.signUpForm.controls.password.value)
    ) {
        return { passwordNotMatch: true };
    }
    return null;
}

  ngOnInit() {
  }
  public  formatDate(date) {
    const d = new Date(date);
    let month = '' + (d.getMonth() + 1);
    let  day = '' + d.getDate();
    const year = d.getFullYear();

    if (month.length < 2)  {
        month = '0' + month;
    }
    if (day.length < 2) {
      day = '0' + day;
    }

    return [day, month, year].join('-');
}
  public registerClick() {
    const date =  this.formatDate(this.signUpForm.get('dob').value);
    const reqbody = {
        userName: this.signUpForm.get('userName').value,
        emailId: this.signUpForm.get('email').value,
        DOB: date,
        mobileNo: this.signUpForm.get('phoneNumber').value,
        password: this.signUpForm.get('password').value,
      };
    if (this.signUpForm.valid) {
    this.signUpService.signUpUser(reqbody)
    .subscribe((response: any) => {
      if (response) {
       if (response.code === '1') {
        this.router.navigate(['place-order']);
       } else if (response.code === 0) {
        alert('Sign Up Failed');
       }
      }

    },
    (error) => {
      console.log(error);
    });
  }
}
}

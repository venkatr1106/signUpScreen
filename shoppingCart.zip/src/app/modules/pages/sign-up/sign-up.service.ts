import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';



@Injectable({
    providedIn: 'root',
})
export class SignUpService {
    constructor(private http: HttpClient) { }

    public signUpUser(reqbody) {

        const httpOptions = {
            headers: new HttpHeaders({
              'Content-Type':  'application/json',
              'Access-Control-Allow-Origin': '*'
            })
          };
        return this.http.post('/test/signup', reqbody, httpOptions);
    }

}
